package com.example.BuilderPractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuilderPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
