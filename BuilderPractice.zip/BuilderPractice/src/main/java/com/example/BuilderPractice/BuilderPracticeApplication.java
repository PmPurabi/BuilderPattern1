package com.example.BuilderPractice;

import com.example.BuilderPractice.Entity.Car;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuilderPracticeApplication {

	public static void main(String[] args) {

		SpringApplication.run(BuilderPracticeApplication.class, args);
		System.out.println(" Practice for Builder pattern");

		Car car = new Car.CarBuilder().setName("Fiesta").setModel("Ford").setColor("Red").setHorsePower(720.5F).setNoOfDoor(4).Build();
		System.out.println(car);
	}
}
