package com.example.BuilderPractice.Entity;

public class Car {
    private String Name;
    private String Color;
    private String Model;
    private Integer NoOfDoors;
    private Integer NoOfWheels;
    private Float HorsePower;

    public Car() {
    }

    public static class CarBuilder {
        private String Name;
        private String Color;
        private String Model;
        private Integer NoOfDoors;
        private Integer NoOfWheels;
        private Float HorsePower;

        public CarBuilder setName(String Name) {
            this.Name = Name;
            return this;
        }
        public CarBuilder setColor(String Color) {
            this.Color = Color;
            return this;
        }
        public CarBuilder setModel(String Model) {
            this.Model = Model;
            return this;
        }
        public CarBuilder setNoOfDoor(Integer NoOfDoors) {
            this.NoOfDoors = NoOfDoors;
            return this;
        }
        public CarBuilder setNoOfWheels(Integer NoOfWheels) {
            this.NoOfWheels = NoOfWheels;
            return this;
        }
        public CarBuilder setHorsePower(Float HorsePower) {
            this.HorsePower = HorsePower;
            return this;
        }
        public Car Build(){
            Car car = new Car();
            car.Name=this.Name;
            car.Model=this.Model;
            car.HorsePower=this.HorsePower;
            car.NoOfWheels=this.NoOfWheels;
            car.NoOfDoors=this.NoOfDoors;
            return car;
        }
    }
    public String getName() {
        return Name;
    }

    public String getColor() {
        return Color;
    }

    public String getModel() {
        return Model;
    }

    public Integer getNoOfDoors() {
        return NoOfDoors;
    }

    public Integer getNoOfWheels() {
        return NoOfWheels;
    }

    public Float getHorsePower() {
        return HorsePower;
    }

    @Override
    public String toString() {
        return "Car{" +
                "Name='" + Name + '\'' +
                ", Color='" + Color + '\'' +
                ", Model='" + Model + '\'' +
                ", NoOfDoors=" + NoOfDoors +
                ", NoOfWheels=" + NoOfWheels +
                ", HorsePower=" + HorsePower +
                '}';
    }
} // Class End
